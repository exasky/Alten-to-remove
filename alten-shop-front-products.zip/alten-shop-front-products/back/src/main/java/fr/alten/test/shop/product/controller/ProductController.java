package fr.alten.test.shop.product.controller;

import fr.alten.test.shop.product.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.swing.*;

@RestController
@RequestMapping(name = "/products")
public class ProductController {

    private ProductService productService;

    @Autowired
    public ProductController(ProductService productService) {
        this.productService = productService;
    }

//    @see https://github.com/exasky/dnd-parker-online/blob/master/back/src/main/java/com/exasky/dnd/adventure/rest/AdventureRestController.java
    @PostMapping()
    public void t() {

    }
}
