package fr.alten.test.shop.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    //@see https://github.com/exasky/dnd-parker-online/tree/master/back/src/main/java/com/exasky/dnd/configuration
}