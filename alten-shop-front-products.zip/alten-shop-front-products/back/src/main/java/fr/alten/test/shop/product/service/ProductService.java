package fr.alten.test.shop.product.service;

import org.springframework.stereotype.Service;

@Service
public class ProductService {
    // @see https://github.com/exasky/dnd-parker-online/blob/master/back/src/main/java/com/exasky/dnd/adventure/service/AdventureService.java

}
