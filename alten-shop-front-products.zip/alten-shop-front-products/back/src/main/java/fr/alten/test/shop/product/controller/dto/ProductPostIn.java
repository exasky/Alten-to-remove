package fr.alten.test.shop.product.controller.dto;

public class ProductPostIn {
}

// @see https://github.com/exasky/dnd-parker-online/tree/master/back/src/main/java/com/exasky/dnd/adventure/rest/dto